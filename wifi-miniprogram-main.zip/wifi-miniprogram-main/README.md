# box

#### 介绍
微信扫码链接wifi

![Image text](https://raw.githubusercontent.com/io24m/wifi-miniprogram/main/screenshot/1.JPG)
![Image text](https://raw.githubusercontent.com/io24m/wifi-miniprogram/main/screenshot/2.PNG)
